-- luacheck: ignore

local Input = Component:new("Input", function(self)
end)
return Input
