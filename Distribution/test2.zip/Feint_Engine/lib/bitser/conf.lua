function love.conf(t)
	t.version = "0.10.0"
	t.console = true
end