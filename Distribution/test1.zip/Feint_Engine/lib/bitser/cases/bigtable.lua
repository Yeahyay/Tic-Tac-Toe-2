local t = {}

for i = 1, 2000 do
	t[i] = 100
end

return t, 500, 5