print('asdjlk;lmklkjnkln')


_DEBUG_LEVEL = 0
_ENV = _G
_ENV_LAST = _G
_TYPE = "SOURCE" -- or MODULE
_LAYER = 0
_REQUIRE_SILENT = false
_NAME = "THREAD_00"
