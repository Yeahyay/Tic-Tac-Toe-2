Composite = Node:extend("Composite")
function Composite:init(name, type, subtype, parent)
	Composite.super.init(self, name, type, subtype, parent)
end
