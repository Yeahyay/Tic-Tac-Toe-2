local t = {}
local x = {10, 50, 40, 30, 20}
for i = 1, 40 do
	t[i] = x
end
return t, 10000, 3