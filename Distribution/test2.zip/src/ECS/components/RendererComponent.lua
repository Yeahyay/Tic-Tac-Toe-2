-- luacheck: ignore

local Renderer = Component:new("Renderer", function(self)
end)
return Renderer
