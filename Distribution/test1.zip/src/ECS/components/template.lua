-- luacheck: ignore

local COMPONENT_NAME = Component:new("COMPONENT_NAME", function(self)
end)
return COMPONENT_NAME
