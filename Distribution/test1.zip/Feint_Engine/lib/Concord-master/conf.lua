function love.conf(t)
   t.identity = "Concord Example"
   t.version  = "11.0"
   t.console  = true
 
   t.window.vsync  = false
   t.window.width  = 720
   t.window.height = 720
 end
 